from rest_framework import serializers
from .models import (
    Profile, Category, Product, 
    Cart, CartItem, Order, 
    OrderItem, Payment, Review
)
from django.contrib.auth.models import User

"""         just about PRODUCTS             """
class ProductSerializer(serializers.ModelSerializer):
    category = serializers.StringRelatedField()
    class Meta:
        model = Product
        exclude = ('image', 'created_at', 'updated_at')
class ProductCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'
        
class ProfileSerializer(serializers.ModelSerializer): # this here for the below CustomerSerializer.
    class Meta:
        model = Profile
        fields = ('phone_number', 'address', 'date_of_birth', 'profile_picture')

class CustomerSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'profile')

"""         just about CUSTOMER/PROFILE             """
class UserProfileSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer(required=True)
    password = serializers.CharField(write_only=True, style={'input_type': 'password'})

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password', 'profile')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        profile_data = validated_data.pop('profile')
        user = User.objects.create_user(**validated_data)
        Profile.objects.create(user=user, **profile_data)
        return user
    
"""         just about CART/CARTITEMS             """
class CartItemSerializer(serializers.ModelSerializer):
    product = serializers.StringRelatedField()
    price = serializers.DecimalField(
        source='product.price',
        max_digits=10, decimal_places=2
    )
    class Meta:
        model = CartItem
        fields = ('id', 'product', 'price','quantity', 'added_at')

class CartSerializer(serializers.ModelSerializer):
    # Nested CartItemSerializer for all items in the cart
    items = CartItemSerializer(many=True, read_only=True)

    class Meta:
        model = Cart
        fields = ('id', 'user', 'created_at', 'updated_at', 'items')


"""             all about the ORDER/ORDERITEMS                  """
class OrderItemSerializer(serializers.ModelSerializer):
    product = serializers.StringRelatedField()
    class Meta:
        model = OrderItem
        fields = ('product','quantity', 'price_at_purchase')


class OrderSerializer(serializers.ModelSerializer):
    total_price = serializers.SerializerMethodField(method_name='get_total')
    user = serializers.CharField(source='user.username')
    items = OrderItemSerializer(many=True)
    
    class Meta:
        model = Order
        fields = ('user', 'status', 'items', 'total_price')

    def get_total(self,obj):
        return sum(item.price_at_purchase  for item in obj.items.all())
    













