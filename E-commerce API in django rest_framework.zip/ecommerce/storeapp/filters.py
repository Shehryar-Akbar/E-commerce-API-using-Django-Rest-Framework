from django_filters import rest_framework
from .models import Product

class ProductFilter(rest_framework.FilterSet):
    class Meta:
        model = Product
        fields = {
            'name': ['icontains'],  # Exact match only
            'price': ['exact', 'lt', 'gt'],  # Exact match only
        }