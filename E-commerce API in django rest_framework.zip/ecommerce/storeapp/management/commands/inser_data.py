from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from faker import Faker
import random
from storeapp.models import (
    Profile, Category, Product, 
    Cart, CartItem, Order, 
    OrderItem, Payment, Review
)

fake = Faker()

class Command(BaseCommand):
    help = 'Seeds the database with fake data'

    def handle(self, *args, **kwargs):
        self.stdout.write("Seeding data...")

        # Create Users and Profiles
        for _ in range(10):
            user = User.objects.create_user(
                username=fake.user_name(),
                email=fake.email(),
                password='password'
            )
            Profile.objects.create(
                user=user,
                phone_number=fake.phone_number(),
                address=fake.address(),
                date_of_birth=fake.date_of_birth(),
                profile_picture=None  # You can add logic to fake images if needed
            )

        # Create Categories
        categories = ['Electronics', 'Clothing', 'Books', 'Home & Kitchen', 'Toys']
        for category_name in categories:
            Category.objects.create(
                name=category_name,
                description=fake.text()
            )

        # Create Products
        categories = Category.objects.all()
        for _ in range(20):
            Product.objects.create(
                name=fake.word(),
                description=fake.text(),
                price=random.uniform(10, 1000),
                stock_quantity=random.randint(1, 100),
                category=random.choice(categories),
                image=None  # You can add logic to fake images if needed
            )

        # Create Carts and CartItems
        users = User.objects.all()
        products = Product.objects.all()
        for user in users:
            cart = Cart.objects.create(user=user)
            for _ in range(random.randint(1, 5)):
                CartItem.objects.create(
                    cart=cart,
                    product=random.choice(products),
                    quantity=random.randint(1, 10)
                )

        # Create Orders and OrderItems
        for user in users:
            order = Order.objects.create(
                user=user,
                total_price=random.uniform(50, 1000),
                status=random.choice(['Pending', 'Shipped', 'Delivered', 'Cancelled'])
            )
            for _ in range(random.randint(1, 5)):
                product = random.choice(products)
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=random.randint(1, 10),
                    price_at_purchase=product.price
                )

        # Create Payments
        orders = Order.objects.all()
        for order in orders:
            Payment.objects.create(
                order=order,
                payment_method=random.choice(['Credit Card', 'PayPal', 'Stripe']),
                amount=order.total_price,
                transaction_id=fake.uuid4(),
                status=random.choice(['Pending', 'Completed', 'Failed'])
            )

        # Create Reviews
        for product in products:
            for _ in range(random.randint(1, 5)):
                Review.objects.create(
                    user=random.choice(users),
                    product=product,
                    rating=random.randint(1, 5),
                    comment=fake.text()
                )

        self.stdout.write(self.style.SUCCESS("Data seeded successfully!"))