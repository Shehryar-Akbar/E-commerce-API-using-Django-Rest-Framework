from django.urls import path, include
from . import views
from django.conf import settings
import debug_toolbar

urlpatterns = [
    path('products/', views.ProductList.as_view(), name='ProductList'),
    path('product-update/<int:pk>', views.UpdateProduct.as_view(), name='update-product'),
    path('create-product/', views.CreateProduct.as_view(), name='create-product'),
    path('customers/', views.CustomersList.as_view(), name='customers'),
    path('create-customer/', views.CreateCustomerAccount.as_view(), name='create-customer'),
    path('cartitmeslist/', views.CartItemView.as_view(), name='cartitemlist'),
    path('cartlist/', views.CartListView.as_view(), name='cartitemlist'),
    path('orders/', views.OrderView.as_view(), name='orderlist'),
]

# Add debug toolbar URLs in development environment
if settings.DEBUG:
    urlpatterns = [
        path('__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns
