from storeapp.models import *
from pprint import pprint
def run():

    orders = Order.objects.first()
    
    total = sum(item.price_at_purchase * item.quantity for item in orders.items.all())
    print(total)