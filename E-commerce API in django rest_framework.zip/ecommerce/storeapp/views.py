from . serializers import (
    ProductSerializer, CustomerSerializer,
    UserProfileSerializer,
    CartItemSerializer,
    CartSerializer,
    OrderSerializer,
    ProductCreateSerializer,
)
from django.db.models import Prefetch
from . models import (
    Product, Profile,
    CartItem, Cart,
    Order, Review, OrderItem,
)
from django.contrib.auth.models import User
from rest_framework import generics
from django_filters.rest_framework import DjangoFilterBackend
from . filters import ProductFilter
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.pagination import PageNumberPagination
# Create your views here.

"""         just about PRODUCTS             """
class ProductList(generics.ListAPIView):
    queryset = Product.objects.select_related('category')
    serializer_class = ProductSerializer
    filter_backends = [
        DjangoFilterBackend,
        # SearchFilter, 
        OrderingFilter
    ]
    filterset_class = ProductFilter
    ordering_field = 'price'
    pagination_class = PageNumberPagination
    pagination_class.page_size = 6


class UpdateProduct(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.select_related('category')
    serializer_class = ProductSerializer

class CreateProduct(generics.CreateAPIView):
    serializer_class = ProductCreateSerializer

"""         just about CUSTOMER/PROFILE             """
class CustomersList(generics.ListAPIView):
    queryset = User.objects.prefetch_related('profile')
    serializer_class = CustomerSerializer

class CreateCustomerAccount(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserProfileSerializer

"""         just about CART/CARTITEMS             """

class CartItemView(generics.ListAPIView):
    queryset = CartItem.objects.select_related('cart', 'product')
    serializer_class = CartItemSerializer

class CartListView(generics.ListAPIView):
    queryset = Cart.objects.prefetch_related('items__product')
    serializer_class = CartSerializer

"""         just about ORDER/ORDERITEMS            """
class OrderView(generics.ListAPIView):
    queryset = Order.objects.select_related('user').prefetch_related(
        Prefetch('items', queryset=OrderItem.objects.select_related('product'))
    )
    serializer_class = OrderSerializer

